Stream Info
===========

A stream info object stores the stream's :term:`lsl:Metadata`.

Doxygen output
--------------

.. doxygenclass:: lsl::stream_info
   :members:

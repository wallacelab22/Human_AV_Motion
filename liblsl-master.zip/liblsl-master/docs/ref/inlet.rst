Stream Inlets
=============

Another text here

:term:`lsl:Stream Inlet`

Doxygen output
--------------

.. doxygenclass:: lsl::stream_inlet
   :members:
